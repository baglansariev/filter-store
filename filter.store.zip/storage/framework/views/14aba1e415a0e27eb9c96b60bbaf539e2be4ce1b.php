

<?php $__env->startSection('content'); ?>

    <!-- breadcrumb start-->














    <!-- breadcrumb start-->



    <!--================Single Product Area =================-->
    <div class="product_image_area section_padding">
        <div class="container">
            <div class="row s_product_inner justify-content-between">
                <div class="col-lg-7 col-xl-7">
                    <div class="product_slider_img">
                        <div id="vertical">
                            <div data-thumb="<?php echo e(asset('assets/filter/img/product/single-product/product_1.png')); ?>">
                                <img src="<?php echo e(asset($product->main_image)); ?>" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-xl-4">
                    <div class="s_product_text">
                        <h3 class="product_name"><?php echo e($product->name); ?></h3>
                        <h2 class="product_price" data-price="<?php echo e($product->price); ?>"><?php echo e($product->price); ?> ₸</h2>
                        <ul class="list">
                            <li>
                                <span>
                                    <span>Категория</span> : <i class="product_category"><?php echo e($product->category->name); ?></i></span>
                            </li>



                        </ul>
                        <p><?php echo e($product->short_desc); ?></p>
                        <div class="card_area d-flex justify-content-between align-items-center">
                            <div class="product_count">
                                <span class="inumber-decrement"> <i class="ti-minus"></i></span>
                                <input class="input-number" type="text" value="1" min="0" max="10">
                                <span class="number-increment"> <i class="ti-plus"></i></span>
                            </div>
                            <button type="button" class="btn_3 order-btn" data-toggle="modal" data-target="#orderModal">Заказать</button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--================End Single Product Area =================-->

    <!--================Product Description Area =================-->
    <section class="product_description_area">
        <div class="container">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
                       aria-selected="true">Описание</a>
                </li>












            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <p>
                        <?php echo e($product->full_desc); ?>

                    </p>
                </div>




































































































































































































































































































































































            </div>
        </div>
    </section>
    <!--================End Product Description Area =================-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filter.store\resources\views/product/single.blade.php ENDPATH**/ ?>