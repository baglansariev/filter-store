<?php
    use App\Http\Controllers\Elements\HeaderController;
    use App\Http\Controllers\Elements\FooterController;
?>
<!DOCTYPE html>
<html lang="ru">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Filters</title>
        <link rel="icon" href="<?php echo e(asset('assets/filter/img/favicon.png')); ?>">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/bootstrap.min.css')); ?>">
        <!-- animate CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/animate.css')); ?>">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/owl.carousel.min.css')); ?>">
        <!-- font awesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/all.css')); ?>">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/flaticon.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/themify-icons.css')); ?>">
        <!-- font awesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/magnific-popup.css')); ?>">
        <!-- swiper CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/slick.css')); ?>">
        <!-- style CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/quiz.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/style.css')); ?>">
    </head>

    <body>
        <!--::header part start::-->
        <?php echo (new HeaderController) -> index(); ?>

        <!-- Header part end-->

        <main>
            <?php echo $__env->yieldContent('content', 'Default Content'); ?>
        </main>


        <!--::footer_part start::-->
        <?php echo (new FooterController) -> index(); ?>

        <!--::footer_part end::-->
        <?php $__env->startComponent('modules.chemical-form'); ?><?php if (isset($__componentOriginale3d3850376c95598ff2abdac7a33947c5384a4e5)): ?>
<?php $component = $__componentOriginale3d3850376c95598ff2abdac7a33947c5384a4e5; ?>
<?php unset($__componentOriginale3d3850376c95598ff2abdac7a33947c5384a4e5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('modules.order-form'); ?><?php if (isset($__componentOriginalbee435c491874774a501a4da0eef055e4a5285a9)): ?>
<?php $component = $__componentOriginalbee435c491874774a501a4da0eef055e4a5285a9; ?>
<?php unset($__componentOriginalbee435c491874774a501a4da0eef055e4a5285a9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('modules.feedback-form'); ?><?php if (isset($__componentOriginal9397dd4f910dd92a5bd0980c803e37a2437fe44c)): ?>
<?php $component = $__componentOriginal9397dd4f910dd92a5bd0980c803e37a2437fe44c; ?>
<?php unset($__componentOriginal9397dd4f910dd92a5bd0980c803e37a2437fe44c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('modules.quiz'); ?><?php if (isset($__componentOriginal77c051c6d23412481cc1529767ccda02e8f68d1c)): ?>
<?php $component = $__componentOriginal77c051c6d23412481cc1529767ccda02e8f68d1c; ?>
<?php unset($__componentOriginal77c051c6d23412481cc1529767ccda02e8f68d1c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <button class="feedback-btn" data-toggle="modal" data-target="#feedbackModal">
            <i class="fas fa-phone"></i>
        </button>

        <!-- jquery plugins here-->
        <script src="<?php echo e(asset('assets/filter/js/jquery-1.12.1.min.js')); ?>"></script>
        <!-- popper js -->
        <script src="<?php echo e(asset('assets/filter/js/popper.min.js')); ?>"></script>
        <!-- bootstrap js -->
        <script src="<?php echo e(asset('assets/filter/js/bootstrap.min.js')); ?>"></script>
        <!-- easing js -->
        <script src="<?php echo e(asset('assets/filter/js/jquery.magnific-popup.js')); ?>"></script>
        <!-- swiper js -->
        <script src="<?php echo e(asset('assets/filter/js/swiper.min.js')); ?>"></script>
        <!-- swiper js -->
        <script src="<?php echo e(asset('assets/filter/js/masonry.pkgd.js')); ?>"></script>
        <!-- particles js -->
        <script src="<?php echo e(asset('assets/filter/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.nice-select.min.js')); ?>"></script>
        <!-- slick js -->
        <script src="<?php echo e(asset('assets/filter/js/slick.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/contact.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.ajaxchimp.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.form.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.validate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/mail-script.js')); ?>"></script>
        <!-- custom js -->
        <script src="<?php echo e(asset('assets/filter/js/maskedinput.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/quiz.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/custom.js')); ?>"></script>
    </body>

</html><?php /**PATH C:\xampp\htdocs\filter.store\resources\views/layouts/default.blade.php ENDPATH**/ ?>