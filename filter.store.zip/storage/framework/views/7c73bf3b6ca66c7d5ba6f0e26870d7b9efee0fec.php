<div class="card">
    <div class="card-header">Меню</div>

    <div class="card-body">
        <ul class="admin-menu">
            <li class="d-flex justify-content-between">
                <a href="<?php echo e(route('category.index')); ?>">Категории</a>
                <span>(<?php echo e($categories->count()); ?>)</span>
            </li>
            <li class="d-flex justify-content-between">
                <a href="<?php echo e(route('product.index')); ?>">Товары</a>
                <span>(<?php echo e($products->count()); ?>)</span>
            </li>
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\filter.store\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>