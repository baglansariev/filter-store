

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <p class="mb-0">Товары</p>
            <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary">Создать</a>
        </div>
        <div class="card-body">

            <?php if(session()->has('msg_success')): ?>
                <div class="card-alert alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session()->get('msg_success')); ?>

                    <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if(session()->has('msg_error')): ?>
                <div class="card-alert alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session()->get('msg_error')); ?>

                    <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </a>
                </div>
            <?php endif; ?>

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Изображение</th>
                        <th scope="col">Наименование</th>
                        <th scope="col">Цена</th>
                        <th scope="col">Категория</th>
                        <th scope="col">Действие</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(isset($products) && $products->count()): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($product->id); ?></th>
                            <td>
                                <img class="table-image" src="<?php echo e(asset($product->main_image)); ?>" alt="">
                            </td>
                            <td>
                                <a href="<?php echo e(route('product.edit', $product->id)); ?>"><?php echo e($product->name); ?></a>
                            </td>
                            <td><?php echo e($product->price); ?> ₸</td>
                            <td>
                                <?php if(isset($product->category)): ?>
                                    <?php echo e($product->category->name); ?>

                                <?php else: ?>
                                    Без категории
                                <?php endif; ?>
                            </td>
                            <td class="d-flex">
                                <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="btn btn-warning mr-1">Изменить</a>
                                <form action="<?php echo e(route('product.destroy', $product->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger">Удалить</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <?php endif; ?>
                </tbody>
            </table>
            <?php if(isset($products) && $products->count()): ?>
                <?php echo e($products->links()); ?>

            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filter.store\resources\views/admin/product/index.blade.php ENDPATH**/ ?>