<?php if(isset($data['name'])): ?>
    Имя клиента: <b><?php echo e($data['name']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['phone'])): ?>
    Телефон клиента: <b><?php echo e($data['phone']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['source'])): ?>
    Источник водоснабжения: <b><?php echo e($data['source']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['object_type'])): ?>
    Тип объекта: <b><?php echo e($data['object_type']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['problem_type'])): ?>
    Проблема: <b><?php echo e($data['problem_type']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['sanuzel'])): ?>
    Количество санузлов: <b><?php echo e($data['sanuzel']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['people_count'])): ?>
    Количество жителей: <b><?php echo e($data['people_count']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['canaliztion'])): ?>
    Тип канализации: <b><?php echo e($data['canaliztion']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['living_type'])): ?>
    Тип проживания: <b><?php echo e($data['living_type']); ?></b>
    <br>
<?php endif; ?>
<?php if(isset($data['warming_type'])): ?>
    Тип отопления: <b><?php echo e($data['warming_type']); ?></b>
    <br>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\filter.store\resources\views/mail/quiz.blade.php ENDPATH**/ ?>