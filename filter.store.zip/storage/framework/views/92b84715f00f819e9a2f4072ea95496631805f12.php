<!doctype html>
<html lang="zxx">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Filters</title>
        <link rel="icon" href="<?php echo e(asset('assets/filter/img/favicon.png')); ?>">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/bootstrap.min.css')); ?>">
        <!-- animate CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/animate.css')); ?>">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/owl.carousel.min.css')); ?>">
        <!-- font awesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/all.css')); ?>">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/flaticon.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/themify-icons.css')); ?>">
        <!-- font awesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/magnific-popup.css')); ?>">
        <!-- swiper CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/slick.css')); ?>">
        <!-- style CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/filter/css/style.css')); ?>">
    </head>

    <body>
    <!--::header part start::-->
        <header class="main_menu home_menu">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index.html">

                                <span style="font-weight: bolder;">Filters</span>
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                    aria-expanded="false" aria-label="Toggle navigation">
                                <span class="menu_icon"><i class="fas fa-bars"></i></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item" id="navbarSupportedContent">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="/">Главная</a>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link " href="#" id="navbarDropdown_1"
                                           role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Фильтры
                                        </a>




                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link" href="#" id="navbarDropdown_3"
                                           role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Акция
                                        </a>








                                    </li>











                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Контакты</a>
                                    </li>
                                </ul>
                            </div>
















                        </nav>
                    </div>
                </div>
            </div>
            <div class="search_input" id="search_input_box">
                <div class="container ">
                    <form class="d-flex justify-content-between search-inner">
                        <input type="text" class="form-control" id="search_input" placeholder="Search Here">
                        <button type="submit" class="btn"></button>
                        <span class="ti-close" id="close_search" title="Close Search"></span>
                    </form>
                </div>
            </div>
        </header>
        <!-- Header part end-->

        <!-- banner part start-->
        <section class="banner_part">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="banner_slider owl-carousel">
                            <div class="single_banner_slider">
                                <div class="row">
                                    <div class="col-lg-5 col-md-8">
                                        <div class="banner_text">
                                            <div class="banner_text_iner">
                                                <h1>УСТАНАВЛИВАЕМ СИСТЕМЫ ДЛЯ ОЧИСТКИ ВОДЫ</h1>
                                                <ul class="banner-list d-flex justify-content-between">
                                                    <li>из скважины</li>
                                                    <li>водопровода</li>
                                                    <li>открытого водозабора</li>
                                                </ul>
                                                <p>
                                                    <b>УЗНАЙТЕ СТОИМОСТЬ ФИЛЬТРА ДЛЯ ОЧИТСКИ ВОДЫ</b>
                                                    <br>
                                                    Ответьте на 5 простых вопросов и получите скидку до 30%*
                                                </p>
                                                <a href="#" class="banner-btn btn_2"> Ответить на вопросы <br> и получить подарок</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="banner_img d-none d-lg-block">
                                        <img src="<?php echo e(asset('assets/filter/images/banner1.1.png')); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
        <!-- banner part start-->

        <!-- feature_part start-->













































        <!-- upcoming_event part start-->

        <!-- product_list start-->
        <section class="product_list section_padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="section_tittle text-center custom-title">
                            <h2>ГОТОВЫЕ КОМПЛЕКТЫ СИСТЕМ ДЛЯ ОЧИСТКИ ВОДЫ</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="product-categories d-flex">
                            <div class="category active" data-tab="1">
                                <img src="<?php echo e(asset('assets/filter/images/categories/1.jpg')); ?>" class="img-fluid" alt="">
                                <div class="category-wrapper">
                                    <p>Питьевые фильтры под мойку</p>
                                </div>
                            </div>
                            <div class="category" data-tab="2">
                                <img src="<?php echo e(asset('assets/filter/images/categories/2.jpg')); ?>" class="img-fluid" alt="">
                                <div class="category-wrapper">
                                    <p>Вода в квартире</p>
                                </div>
                            </div>
                            <div class="category" data-tab="3">
                                <img src="<?php echo e(asset('assets/filter/images/categories/3.jpg')); ?>" class="img-fluid" alt="">
                                <div class="category-wrapper">
                                    <p>Вода на даче</p>
                                </div>
                            </div>
                            <div class="category" data-tab="4">
                                <img src="<?php echo e(asset('assets/filter/images/categories/4.jpg')); ?>" class="img-fluid" alt="">
                                <div class="category-wrapper">
                                    <p>Вода в коттедже</p>
                                </div>
                            </div>
                            <div class="category" data-tab="5">
                                <img src="<?php echo e(asset('assets/filter/images/categories/5.jpg')); ?>" class="img-fluid" alt="">
                                <div class="category-wrapper">
                                    <p>Вода для производств</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row products-tab active" id="p-tab1">
                    <div class="col-lg-12">
                        <div class="product_list_slider owl-carousel">
                            <div class="single_product_list_slider">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row products-tab" id="p-tab2">
                    <div class="col-lg-12">
                        <div class="product_list_slider owl-carousel">
                            <div class="single_product_list_slider">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row products-tab" id="p-tab3">
                    <div class="col-lg-12">
                        <div class="product_list_slider owl-carousel">
                            <div class="single_product_list_slider">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row products-tab" id="p-tab4">
                    <div class="col-lg-12">
                        <div class="product_list_slider owl-carousel">
                            <div class="single_product_list_slider">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row products-tab" id="p-tab5">
                    <div class="col-lg-12">
                        <div class="product_list_slider owl-carousel">
                            <div class="single_product_list_slider">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6">
                                        <div class="single_product_item">
                                            <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                            <div class="single_product_text">
                                                <h4>Фильтр для очистки</h4>
                                                <h3>$150.00</h3>
                                                <a href="#" class="add_cart">+ заказать</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
        </section>
        <!-- product_list part start-->

        <section class="water-bg">
            <div class="container">
                <div class="row">
                    <div class="row justify-content-center">
                        <div class="col-lg-12">
                            <div class="section_tittle text-center custom-title">
                                <h2 class="d-flex flex-column">
                                    <span class="mb-3">ОЧИСТИТЕ ВОДУ ОТ ВСЕХ ИЗВЕСТНЫХ ВИДОВ ПРИМЕСЕЙ</span>
                                    <span>ЗАКАЗАВ ПРОВЕДЕНИЕ ХИМ. АНАЛИЗА</span>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="water-img d-flex align-items-center justify-content-center">
                <img src="<?php echo e(asset('assets/filter/images/water_bg.jpg')); ?>" alt="" class="img-fluid">
            </div>
        </section>

        <!-- awesome_shop start-->
        <section class="our_offer section_padding">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-6 col-md-6">
                        <div class="offer_img">
                            <img src="<?php echo e(asset('assets/filter/images/banner1.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="offer_text">
                            <h2>Ежемесячная акция на филтры 20%</h2>
                            <div class="date_countdown">
                                <div id="timer">
                                    <div id="days" class="date"></div>
                                    <div id="hours" class="date"></div>
                                    <div id="minutes" class="date"></div>
                                    <div id="seconds" class="date"></div>
                                </div>
                            </div>
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Ваш E-mail адрес"
                                       aria-label="Recipient's username" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <a href="#" class="input-group-text btn_2" id="basic-addon2">Заказать</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- awesome_shop part start-->

        <!-- product_list part start-->
        <section class="product_list best_seller section_padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="section_tittle text-center">
                            <h2>Топ продающиеся</h2>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-12">
                        <div class="best_product_slider owl-carousel">
                            <div class="single_product_item">
                                <img src="<?php echo e(asset('assets/filter/images/products/product1.png')); ?>" alt="">
                                <div class="single_product_text">
                                    <h4>Фильтр для очистки</h4>
                                    <h3>$150.00</h3>
                                </div>
                            </div>
                            <div class="single_product_item">
                                <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                <div class="single_product_text">
                                    <h4>Фильтр для очистки</h4>
                                    <h3>$150.00</h3>
                                </div>
                            </div>
                            <div class="single_product_item">
                                <img src="<?php echo e(asset('assets/filter/images/products/product3.png')); ?>" alt="">
                                <div class="single_product_text">
                                    <h4>Фильтр для очистки</h4>
                                    <h3>$150.00</h3>
                                </div>
                            </div>
                            <div class="single_product_item">
                                <img src="<?php echo e(asset('assets/filter/images/products/product4.png')); ?>" alt="">
                                <div class="single_product_text">
                                    <h4>Фильтр для очистки</h4>
                                    <h3>$150.00</h3>
                                </div>
                            </div>
                            <div class="single_product_item">
                                <img src="<?php echo e(asset('assets/filter/images/products/product2.png')); ?>" alt="">
                                <div class="single_product_text">
                                    <h4>Фильтр для очистки</h4>
                                    <h3>$150.00</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- product_list part end-->

        <!-- subscribe_area part start-->
        <section class="subscribe_area section_padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <div class="subscribe_area_text text-center">
                            <h5>Заполните форму заявку и наш специалист будет в пути через 5 минут и решит Вашу проблему в короткий срок</h5>
                            <h2 style="color: #fff;">Наш специалист готов выехать на ваш вызов через 5 минут</h2>
                            <div class="input-group">
                                <input type="text" class="form-control delivery-input" placeholder="Ваш телефон" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button class="input-group-text btn_2" id="deliveryBtn">Вызвать</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--::subscribe_area part end::-->

        <!-- subscribe_area part start-->













































        <!--::subscribe_area part end::-->


    <!-- ================ contact section start ================= -->
    <section class="contact-section padding_top">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section_tittle text-center">
                        <h2>Наши контакты</h2>
                    </div>
                </div>
            </div>
            <div class="d-none d-sm-block mb-5 pb-4">
                <div id="map" style="height: 480px;"></div>
                <script>
                    function initMap() {
                        var uluru = {
                            lat: -25.363,
                            lng: 131.044
                        };
                        var grayStyles = [{
                            featureType: "all",
                            stylers: [{
                                saturation: -90
                            },
                                {
                                    lightness: 50
                                }
                            ]
                        },
                            {
                                elementType: 'labels.text.fill',
                                stylers: [{
                                    color: '#ccdee9'
                                }]
                            }
                        ];
                        var map = new google.maps.Map(document.getElementById('map'), {
                            center: {
                                lat: -31.197,
                                lng: 150.744
                            },
                            zoom: 9,
                            styles: grayStyles,
                            scrollwheel: false
                        });
                    }
                </script>
                <script
                        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDpfS1oRGreGSBU5HHjMmQ3o5NLw7VdJ6I&callback=initMap">
                </script>

            </div>


            <div class="row">
                <div class="col-12">
                    <h2 class="contact-title">Напишите нам</h2>
                </div>
                <div class="col-lg-8">
                    <form class="form-contact contact_form" action="contact_process.php" method="post" id="contactForm"
                          novalidate="novalidate">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">

                  <textarea class="form-control w-100" name="message" id="message" cols="30" rows="9"
                            onfocus="this.placeholder = ''" onblur="this.placeholder = 'Сообщение'"
                            placeholder='Сообщение'></textarea>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input class="form-control" name="name" id="name" type="text" onfocus="this.placeholder = ''"
                                           onblur="this.placeholder = 'Ваше имя'" placeholder='Ваше имя'>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input class="form-control" name="email" id="email" type="email" onfocus="this.placeholder = ''"
                                           onblur="this.placeholder = 'Ваш e-mail'" placeholder='Ваш e-mail'>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <input class="form-control" name="subject" id="subject" type="text" onfocus="this.placeholder = ''"
                                           onblur="this.placeholder = 'Тема'" placeholder='Тема'>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <a href="#" class="btn_3 button-contactForm">Отправить</a>
                        </div>
                    </form>
                </div>
                <div class="col-lg-4">
                    <div class="media contact-info">
                        <span class="contact-info__icon"><i class="ti-home"></i></span>
                        <div class="media-body">
                            <h3>Шымкент, Казахстан.</h3>
                            <p>ул.Казыбек би, 51 д.</p>
                        </div>
                    </div>
                    <div class="media contact-info">
                        <span class="contact-info__icon"><i class="ti-tablet"></i></span>
                        <div class="media-body">
                            <h3>00 (440) 9865 562</h3>
                            <p>Пн-Пт от 09:00 до 18:00</p>
                        </div>
                    </div>
                    <div class="media contact-info">
                        <span class="contact-info__icon"><i class="ti-email"></i></span>
                        <div class="media-body">
                            <h3>support@filters.com</h3>
                            <p>Пишите нам в любое время</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ================ contact section end ================= -->



        <!--::footer_part start::-->
        <footer class="footer_part">
            <div class="container">


































































            </div>
            <div class="copyright_part">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="copyright_text text-center">
                                <P><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> Все права защищены! | Разработка и поддержка сайта - <a href="https://relevantkz" target="_blank">RELEVANT</a>
                                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></P>
                            </div>
                        </div>
                        <div class="col-lg-4">








                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--::footer_part end::-->

        <!-- jquery plugins here-->
        <script src="<?php echo e(asset('assets/filter/js/jquery-1.12.1.min.js')); ?>"></script>
        <!-- popper js -->
        <script src="<?php echo e(asset('assets/filter/js/popper.min.js')); ?>"></script>
        <!-- bootstrap js -->
        <script src="<?php echo e(asset('assets/filter/js/bootstrap.min.js')); ?>"></script>
        <!-- easing js -->
        <script src="<?php echo e(asset('assets/filter/js/jquery.magnific-popup.js')); ?>"></script>
        <!-- swiper js -->
        <script src="<?php echo e(asset('assets/filter/js/swiper.min.js')); ?>"></script>
        <!-- swiper js -->
        <script src="<?php echo e(asset('assets/filter/js/masonry.pkgd.js')); ?>"></script>
        <!-- particles js -->
        <script src="<?php echo e(asset('assets/filter/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.nice-select.min.js')); ?>"></script>
        <!-- slick js -->
        <script src="<?php echo e(asset('assets/filter/js/slick.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/contact.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.ajaxchimp.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.form.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/jquery.validate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/mail-script.js')); ?>"></script>
        <!-- custom js -->
        <script src="<?php echo e(asset('assets/filter/js/maskedinput.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/filter/js/custom.js')); ?>"></script>
    </body>

</html><?php /**PATH C:\xampp\htdocs\filter.store\resources\views/home2.blade.php ENDPATH**/ ?>