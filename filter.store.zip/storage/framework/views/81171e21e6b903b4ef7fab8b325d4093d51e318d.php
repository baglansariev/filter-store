

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <p class="mb-0">Изменение товара</p>
        </div>
        <div class="card-body">
            <?php if(isset($product) && !empty($product)): ?>
                <form method="post" action="<?php echo e(route('product.update', $product->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="PUT">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="c-label" for="inputName">Наименование</label>
                                <input type="text" class="form-control" name="name" id="inputName" aria-describedby="emailHelp" placeholder="Наименование" value="<?php echo e($product->name); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="c-label" for="inputShortDesc">Краткое описание</label>
                                <textarea name="short_desc" id="inputShortDesc" class="form-control"><?php echo e($product->short_desc ?? ''); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label class="c-label" for="inputCategory">Категория</label>
                                <select name="category" id="inputCategory" class="form-control" required>
                                    <?php if(isset($categories) && $categories->count()): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($product->category) && $product->category->id == $category->id): ?>
                                                <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="0">Выбрать</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="c-label" for="inputPrice">Цена</label>
                                <input type="number" name="price" class="form-control" id="inputPrice" placeholder="Цена" required value="<?php echo e($product->price); ?>">
                            </div>
                            <div class="form-group">
                                <label class="c-label" for="inputFullDesc">Полное описание</label>
                                <textarea name="full_desc" id="inputFullDesc" class="form-control" required><?php echo e($product->full_desc ?? ''); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label class="c-label" for="inputImage">Изображение</label>
                                <div class="image_edit d-flex flex-column align-items-start">
                                    <button id="img_change" type="button">
                                        <img src="<?php echo e(asset($product->main_image)); ?>" alt="">
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="buttons d-flex justify-content-end mt-3 mb-3">
                        <button type="submit" class="btn btn-success mr-1">Сохранить</button>
                        <a href="<?php echo e(route('product.index')); ?>" class="btn btn-danger">Отменить</a>
                    </div>
                </form>
            <?php else: ?>
                <p>Такой товар не существует</p>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filter.store\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>