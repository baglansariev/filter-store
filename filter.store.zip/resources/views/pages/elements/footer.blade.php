<footer class="footer_part">
    <div class="container"></div>
    <div class="copyright_part">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright_text text-center">
                        <p>
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> Все права защищены! | Разработка и поддержка сайта - <a href="https://relevantkz" target="_blank">RELEVANT</a>
                        </p>
                    </div>
                </div>
                <div class="col-lg-4"></div>
            </div>
        </div>
    </div>
</footer>