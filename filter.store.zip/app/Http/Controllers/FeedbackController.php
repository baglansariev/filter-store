<?php

namespace App\Http\Controllers;

use App\Mail\Quiz;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class FeedbackController extends Controller
{
    public function quizSend(Request $request)
    {
        $this->send($request, new Quiz($request->all()));
        return redirect('/');
    }

    public function feedbackFormSend(Request $request)
    {

    }

    public function send(Request $request, $mailable)
    {
        $mail = Mail::to(env('MAIL_USERNAME'));
        if ($mail->send($mailable)) {
            session()->flash('msg_success', 'Ваша заявка успешно отправлена!');
        }
        else {
            session()->flash('msg_error', 'Произошла ошибка. Попробуйте позже!');
        }
    }
}
